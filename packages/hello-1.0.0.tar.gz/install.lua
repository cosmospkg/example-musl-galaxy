function install()
  copy("bin/hello", "/usr/bin/hello")
end
